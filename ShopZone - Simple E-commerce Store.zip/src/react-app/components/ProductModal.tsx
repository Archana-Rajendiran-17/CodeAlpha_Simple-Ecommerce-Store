import { Star, ExternalLink, X, ShoppingCart, Heart } from "lucide-react";
import { Product } from "@/react-app/data/products";
import { Button } from "@/react-app/components/ui/button";
import { Badge } from "@/react-app/components/ui/badge";
import { Dialog, DialogContent } from "@/react-app/components/ui/dialog";

interface ProductModalProps {
  product: Product | null;
  open: boolean;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function ProductModal({ product, open, onClose, onAddToCart }: ProductModalProps) {
  if (!product) return null;

  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl p-0 overflow-hidden">
        <div className="grid md:grid-cols-2 gap-0">
          {/* Image Section */}
          <div className="relative bg-gradient-to-br from-muted/50 to-muted">
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-64 md:h-full object-cover"
            />
            {discount > 0 && (
              <Badge className="absolute top-4 left-4 bg-green-500 hover:bg-green-500 text-white font-semibold text-sm px-3 py-1">
                {discount}% OFF
              </Badge>
            )}
            <Button
              variant="ghost"
              size="icon"
              className="absolute top-4 right-4 bg-white/80 hover:bg-white rounded-full"
              onClick={onClose}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Details Section */}
          <div className="p-6 flex flex-col">
            <p className="text-sm font-medium text-primary uppercase tracking-wider mb-2">
              {product.category}
            </p>

            <h2 className="text-2xl font-bold text-foreground mb-3">{product.name}</h2>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-4">
              <div className="flex items-center gap-1.5 bg-green-500 px-2.5 py-1 rounded-md">
                <Star className="w-4 h-4 fill-white text-white" />
                <span className="text-sm font-semibold text-white">{product.rating}</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {product.reviews.toLocaleString()} reviews
              </span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-4">
              <span className="text-3xl font-bold text-foreground">
                ₹{product.price.toLocaleString()}
              </span>
              {product.originalPrice && (
                <>
                  <span className="text-lg text-muted-foreground line-through">
                    ₹{product.originalPrice.toLocaleString()}
                  </span>
                  <span className="text-green-600 font-medium">
                    Save ₹{(product.originalPrice - product.price).toLocaleString()}
                  </span>
                </>
              )}
            </div>

            {/* Description */}
            <p className="text-muted-foreground mb-6 flex-1">{product.description}</p>

            {/* Actions */}
            <div className="space-y-3">
              <div className="flex gap-3">
                <Button
                  className="flex-1 gap-2"
                  size="lg"
                  onClick={() => onAddToCart(product)}
                >
                  <ShoppingCart className="w-4 h-4" />
                  Add to Cart
                </Button>
                <Button variant="outline" size="lg">
                  <Heart className="w-4 h-4" />
                </Button>
              </div>

              {/* Buy Links */}
              <div className="pt-4 border-t border-border">
                <p className="text-sm font-medium text-foreground mb-3">Buy from:</p>
                <div className="flex gap-2">
                  {product.buyLinks.amazon && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-1.5"
                      onClick={() => window.open(product.buyLinks.amazon, "_blank")}
                    >
                      <span className="font-semibold text-orange-500">Amazon</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Button>
                  )}
                  {product.buyLinks.flipkart && (
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1 gap-1.5"
                      onClick={() => window.open(product.buyLinks.flipkart, "_blank")}
                    >
                      <span className="font-semibold text-blue-500">Flipkart</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
