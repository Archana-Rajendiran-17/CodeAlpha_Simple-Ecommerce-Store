import { Star, ExternalLink } from "lucide-react";
import { Product } from "@/react-app/data/products";
import { Button } from "@/react-app/components/ui/button";
import { Badge } from "@/react-app/components/ui/badge";

interface ProductCardProps {
  product: Product;
  onViewDetails: (product: Product) => void;
}

export default function ProductCard({ product, onViewDetails }: ProductCardProps) {
  const discount = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  return (
    <div className="group relative bg-card rounded-2xl overflow-hidden border border-border/50 hover:border-primary/30 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5">
      {/* Discount Badge */}
      {discount > 0 && (
        <Badge className="absolute top-3 left-3 z-10 bg-green-500 hover:bg-green-500 text-white font-semibold">
          {discount}% OFF
        </Badge>
      )}

      {/* Product Image */}
      <div className="relative h-56 overflow-hidden bg-gradient-to-br from-muted/50 to-muted">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Content */}
      <div className="p-5">
        {/* Category */}
        <p className="text-xs font-medium text-primary uppercase tracking-wider mb-2">
          {product.category}
        </p>

        {/* Name */}
        <h3 className="font-semibold text-foreground line-clamp-2 mb-2 group-hover:text-primary transition-colors">
          {product.name}
        </h3>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-1 bg-green-500/10 px-2 py-0.5 rounded-full">
            <Star className="w-3.5 h-3.5 fill-green-500 text-green-500" />
            <span className="text-sm font-medium text-green-600">{product.rating}</span>
          </div>
          <span className="text-xs text-muted-foreground">
            ({product.reviews.toLocaleString()} reviews)
          </span>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2 mb-4">
          <span className="text-2xl font-bold text-foreground">
            ₹{product.price.toLocaleString()}
          </span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              ₹{product.originalPrice.toLocaleString()}
            </span>
          )}
        </div>

        {/* Actions */}
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            className="flex-1"
            onClick={() => onViewDetails(product)}
          >
            View Details
          </Button>
          <Button
            size="sm"
            className="flex-1 gap-1.5"
            onClick={() => {
              const link = product.buyLinks.amazon || product.buyLinks.flipkart || product.buyLinks.other;
              if (link) window.open(link, "_blank");
            }}
          >
            Buy Now
            <ExternalLink className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
